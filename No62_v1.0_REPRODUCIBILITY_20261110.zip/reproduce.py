#!/usr/bin/env python3
"""No.62 v0.3 local reproducibility runner; standard library only.

Verifies exact inventory, SHA256 manifest, frozen files and stdout.
Compiles frozen C++17 into a temporary directory, never overwrites evidence.
"""
from __future__ import annotations
import hashlib
import pathlib
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent


def digest(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def parse_manifest(path: pathlib.Path) -> dict[str, str]:
    expected = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        h, sep, name = line.partition('  ')
        if (not sep or len(h) != 64 or name in expected or
                name.startswith('/') or name.startswith('../') or
                '/..' in name or '\\' in name):
            raise RuntimeError('Invalid or duplicate manifest entry: ' + repr(line))
        expected[name] = h
    return expected


def check_inventory(directory: pathlib.Path, manifest: pathlib.Path) -> int:
    expected = parse_manifest(manifest)
    existing = {p.relative_to(directory).as_posix()
                for p in directory.rglob('*') if p.is_file() and p != manifest}
    if existing != set(expected):
        raise RuntimeError('Inventory mismatch: missing=' + str(sorted(set(expected)-existing))
                           + ' extra=' + str(sorted(existing-set(expected))))
    for rel, sha in expected.items():
        actual = digest(directory / rel)
        if sha.lower() != actual:
            raise RuntimeError('SHA mismatch: ' + rel)
    return len(expected)


def check_frozen_inventory(directory: pathlib.Path, manifest: pathlib.Path) -> int:
    expected = parse_manifest(manifest)
    existing = {p.relative_to(directory).as_posix()
                for p in directory.rglob('*') if p.is_file()}
    if existing != set(expected):
        raise RuntimeError('Frozen inventory mismatch: ' + str(sorted(existing ^ set(expected))))
    for name, sha in expected.items():
        if digest(directory / name) != sha:
            raise RuntimeError('Frozen SHA mismatch: ' + name)
    return len(expected)


def run(args: list[str], cwd: pathlib.Path) -> str:
    result = subprocess.run(args, cwd=str(cwd), text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError('Command failed with code ' + str(result.returncode)
                           + ': ' + ' '.join(args) + '\n' + result.stderr[-3000:])
    return result.stdout


def check_stdout(name: str, output: str, token: str) -> None:
    expected = (ROOT / 'frozen' / name).read_text(encoding='utf-8')
    if output.replace('\r\n', '\n') != expected.replace('\r\n', '\n'):
        raise RuntimeError(name + ' stdout mismatch')
    if token not in output:
        raise RuntimeError(name + ' success marker missing')


def main() -> int:
    if sys.version_info < (3, 10):
        raise RuntimeError('Python >=3.10 is required')
    if sys.flags.optimize:
        raise RuntimeError('Python -O is prohibited; assertions must remain enabled')
    count = check_inventory(ROOT, ROOT / 'SHA256SUMS_RELEASE.txt')
    print('PASS release inventory and SHA256:', count, 'files')
    count = check_frozen_inventory(ROOT / 'frozen', ROOT / 'SHA256SUMS_FROZEN.txt')
    print('PASS retained original frozen verifier files and SHA256:', count, 'files')
    pyout = run([sys.executable, '-B', '-I', str(ROOT / 'frozen' / 'verify_infinite.py')], ROOT / 'frozen')
    check_stdout('verification_infinite_stdout.txt', pyout, 'INFINITE_UPPER_CERTIFICATE_PASS')
    print('PASS Python all-n upper-bound certificate and exact frozen stdout')
    cxx = shutil.which('g++') or shutil.which('clang++') or shutil.which('cl')
    if not cxx:
        print('PARTIAL: NO C++17 COMPILER FOUND; finite exhaustive certificate NOT RUN')
        return 3
    with tempfile.TemporaryDirectory(prefix='no62_reproduce_') as tmp:
        tmp = pathlib.Path(tmp)
        exe = tmp / ('no62_finite.exe' if sys.platform == 'win32' else 'no62_finite')
        src = ROOT / 'frozen' / 'verify_finite.cpp'
        if pathlib.Path(cxx).name.lower() in ('cl', 'cl.exe'):
            compile_cmd = [cxx, '/nologo', '/O2', '/EHsc', '/std:c++17',
                           '/Fe:' + str(exe), str(src)]
        else:
            compile_cmd = [cxx, '-std=c++17', '-O3', str(src), '-o', str(exe)]
        run(compile_cmd, tmp)
        cppout = run([str(exe)], tmp)
        check_stdout('verification_finite_stdout.txt', cppout, 'FINITE_VERIFIER_PASS')
    print('PASS C++17 finite exhaustive certificate and exact frozen stdout')
    print('ALL_CERTIFICATES_PASS (local execution; NOT an independent formal proof)')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as e:
        print('FAIL:', str(e), file=sys.stderr)
        sys.exit(1)
