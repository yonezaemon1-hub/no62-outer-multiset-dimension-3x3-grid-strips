# No.62 v0.3 Windows reproduction summary

The author supplied a Windows PowerShell 5.1 execution transcript for the
exact v0.3 package, dated 2026-11-10 in Japan. The reported outcome is PASS.

- Environment: Windows 10, Windows PowerShell 5.1, Python and a C++17 compiler.
- Release inventory and SHA-256: 14 files passed.
- Frozen verifier and output inventory and SHA-256: four files passed.
- The Python all-n upper-bound certificate and the C++17 finite exhaustive
  certificate passed. Both outputs matched the frozen records.
- The transcript records ALL_CERTIFICATES_PASS and WINDOWS_REPRODUCTION_PASS.

This is a sanitized account of the author-supplied v0.3 run. The v1.0
distribution was checked on Linux. Independent AI review is separately
reported through v0.3 within its stated scope.

Copyright (c) 2026 Ryutaro Yonezu. All rights reserved.
