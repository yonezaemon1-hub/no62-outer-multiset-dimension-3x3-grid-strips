// No.62 exploratory finite verifier: a second checker using power sums,
// independently of the sorted-distance signature checker used during discovery.
// C++17. Each multiset of k integer distances is determined by its first k
// power sums via Newton's identities over Q.
#include <array>
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <string>
#include <unordered_set>
#include <vector>
using namespace std;
using Vertex=array<int,3>;
using Signature=array<long long,6>;
struct Hasher { size_t operator()(const Signature &a) const {size_t h=1469598103934665603ULL;for(long long x:a){h ^= size_t(x+0x9e3779b9);h*=1099511628211ULL;}return h;}};
struct Grid {
  int n;
  vector<Vertex> vs;
  vector<vector<int>> d;
  explicit Grid(int nn):n(nn){
    for(int x=0;x<3;x++)for(int y=0;y<3;y++)for(int z=0;z<n;z++)vs.push_back({x,y,z});
    int m=vs.size();d.assign(m,vector<int>(m));
    for(int i=0;i<m;i++)for(int j=0;j<m;j++)for(int k=0;k<3;k++)d[i][j]+=abs(vs[i][k]-vs[j][k]);
  }
  bool resolving(const vector<int>& S) const {
    unordered_set<Signature,Hasher> seen;
    for(int v=0;v<(int)vs.size();v++){
      bool selected=false;for(int w:S)if(v==w)selected=true;
      if(selected)continue;
      Signature powers{};
      for(int w:S){long long p=1;for(int j=0;j<(int)S.size();j++){p*=d[v][w];powers[j]+=p;}}
      if(!seen.insert(powers).second)return false;
    }
    return true;
  }
  vector<int> first_witness(int k,long long& checked) const {
    vector<int> s;
    vector<int> answer;
    auto dfs=[&](auto&& self,int from)->bool{
      if((int)s.size()==k){++checked;if(resolving(s)){answer=s;return true;}return false;}
      for(int j=from;j<=(int)vs.size()-(k-(int)s.size());j++){
        s.push_back(j);
        if(self(self,j+1))return true;
        s.pop_back();
      }
      return false;
    };
    dfs(dfs,0);return answer;
  }
};
int main(){
 for(int n=2;n<=8;n++){
  Grid G(n);long long checked=0;
  auto w=G.first_witness(4,checked);
  cout<<"NO4 n="<<n<<" exhaustive="<<(w.empty()?"YES":"NO")<<" checked="<<checked<<"\n";
  if(!w.empty())return 2;
 }
 {
  Grid G(3);long long checked=0;auto w=G.first_witness(5,checked);
  cout<<"NO5 n=3 exhaustive="<<(w.empty()?"YES":"NO")<<" checked="<<checked<<"\n";
  if(!w.empty())return 3;
 }
 // Existence witnesses, from the first sorted-distance discovery algorithm.
 const vector<pair<int,vector<Vertex>>> witnesses={
  {2,{{0,0,0},{0,0,1},{0,1,0},{0,2,0},{2,0,1}}},
  {3,{{0,0,0},{0,0,1},{0,0,2},{0,1,0},{1,1,2},{2,0,0}}},
  {4,{{0,0,0},{0,0,1},{0,0,3},{0,1,1},{0,2,3}}},
  {5,{{0,0,0},{0,0,1},{0,0,2},{0,1,4},{0,2,0}}},
  {6,{{0,0,0},{0,0,1},{0,0,3},{0,2,1},{2,2,0}}},
  {7,{{0,0,0},{0,0,1},{0,0,2},{0,0,6},{0,2,1}}},
  {8,{{0,0,0},{0,0,1},{0,0,2},{0,0,7},{0,2,4}}},
  {10,{{0,0,0},{0,0,6},{0,2,8},{2,2,5}}}
 };
 for(const auto& item:witnesses){
  Grid G(item.first);vector<int>s;
  for(Vertex w:item.second){bool found=false;for(int i=0;i<(int)G.vs.size();i++)if(G.vs[i]==w){s.push_back(i);found=true;break;}if(!found)return 4;}
  bool ok=G.resolving(s);cout<<"WITNESS n="<<item.first<<" k="<<s.size()<<" valid="<<(ok?"YES":"NO")<<"\n";if(!ok)return 5;
 }
 cout<<"FINITE_VERIFIER_PASS\n";
}
