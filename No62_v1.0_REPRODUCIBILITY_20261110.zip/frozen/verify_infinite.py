#!/usr/bin/env python3
"""No.62 exploratory computer-assisted universal upper-bound certificate.

Verifies 4-landmark construction for all n>=32 by finite prefix checks and
an exact, parity-aware bounded-offset collision test. For 9<=n<=31, checks
all vertices directly. This is an exploratory certificate, NOT peer reviewed.
"""
from itertools import product


def S(n):
    if n == 10:
        return ((0,0,0),(0,0,6),(0,2,8),(2,2,5))
    c = 3 if n%2 else 6
    return ((0,0,0),(0,0,1),(0,0,n-1),(0,2,c))


def dist(u,v):
    return sum(abs(a-b) for a,b in zip(u,v))


def direct_check(n):
    landmarks=S(n)
    outside=[v for v in product(range(3),range(3),range(n)) if v not in landmarks]
    encodings=[tuple(sorted(dist(v,w) for w in landmarks)) for v in outside]
    return len(encodings)==len(set(encodings))


def near_injectivity(c):
    # n>=32: fourth landmark C at (0,0,n-1) is unique maximal distance
    # on the finite prefix z<=c+7. Therefore check (p-z, sorted other 3).
    seen={}
    exclusions={(0,0,0),(0,0,1),(0,2,c)}
    for x,y,z in product(range(3),range(3),range(c+8)):
        v=(x,y,z)
        if v in exclusions:continue
        p=x+y
        key=(p-z,tuple(sorted((p+z,p+abs(z-1),x+2-y+abs(z-c)))))
        assert key not in seen,(c,seen.get(key),v,key)
        seen[key]=v
    return len(seen)


def tail_no_collisions(c,parity):
    # z,z'>=c implies equal distance sums => z'-z=2(x-x')+(y-y').
    # With t=p+z, the two multiset signatures, shifted by -t, are
    # (0,-1,2-2y-c,h) and
    # (dx,dx-1,dx+2-2y'-c,h-3dx-2dy), h=n-1-2z.
    # For |h|>30, the h-containing terms are unique extreme entries;
    # equality forces 3dx+2dy=0 and hence dx=dy=0, i.e. same vertex.
    # All remaining cases are the following exact finite integer checks.
    cnt=0
    for x,y,xp,yp in product(range(3),repeat=4):
        dx=x-xp;dy=y-yp
        if dx==0 and dy==0:continue
        for h in range(-30,31):
            if h%2 != parity:continue
            left=sorted((0,-1,2-2*y-c,h))
            right=sorted((dx,dx-1,dx+2-2*yp-c,h-3*dx-2*dy))
            assert left!=right,(c,x,y,xp,yp,h)
            cnt+=1
    return cnt


def main():
    for n in range(9,32):
        assert direct_check(n),n
        print(f"PASS direct n={n} k=4")
    for c,parity in ((3,0),(6,1)):
        count=near_injectivity(c)
        checks=tail_no_collisions(c,parity)
        print(f"PASS infinite parity={('odd' if parity==0 else 'even')} c={c}: "
              f"prefix_unique={count}, tail_checked={checks}, outlier_bound=30")
    for n in (32,33,40,41,100,101,200,201):
        assert direct_check(n),n
        print(f"PASS spotcheck n={n} k=4")
    print("INFINITE_UPPER_CERTIFICATE_PASS (computer-assisted, not externally audited)")

if __name__=='__main__':main()
